package oop_lab4.field;

import java.awt.Point;
import java.util.Random;
 
/**
 * Служебный класс для работы с координатами  
 */
public class utilCoords {
   
    
}