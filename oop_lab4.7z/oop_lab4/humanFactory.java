package oop_lab4;

import oop_lab4.human_classes.Human;

public interface humanFactory { 
        Human create();
} 
